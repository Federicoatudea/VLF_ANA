{
 gROOT->Reset();
 gROOT->SetStyle("Plain");
 gStyle->SetOptStat(00);
 ifstream sgnal,mcw,mctop;
 ofstream ssb;
 int ndt=72000;
 
 sgnal.open("signal200197total.dat");
 mcw.open("wjetstotal.dat");
 mctop.open("singletoptotal.dat");
 ssb.open("significance200197.dat");

 double muonptcut[10]={4.0,6.0,6.0,8.0,10.0,12.0,15.0,20.0,24.0,28.0};
 int njetscut[4]={1,2,3,4}; //dont use this cut
 double lptcut[6]={50.0,100.0,150.0,200.0,250.0,300.0};
 double metcut[5]={50.0,100.0,150.0,200.0,300.0};
 double mtcut[10]={0.0,2.0,4.0,8.0,12.0,16.0,20.0,30.0,40.0,60.0};
 double dphicut[6]={0.0,0.5,1.0,1.5,2.0,3.0};
 double dphijetmetcut[8]={0.1,0.2,0.4,0.6,1.0,1.5,2.0,3.0};  // cuts high |jet-met|-pi, selects backtoback jetmet

 
 double lumi=100; // projected lumi in fb-1
 double lumisignal, lumiw,lumitop;
 double xs_wjets=3092000.0; //fb
 double xs_top=288000.0; //fb
 //double xs_signal=332.0;//fb
 //double xs_signal=91.6;//fb
 double xs_signal=35.12;//fb

 double scale_signal,scale_w,scale_top;

 int sval[160000][16], wval[160000][16], tval[160000][16];
 double s_sb[160000][16];
 for (int i=0;i<ndt;i++){
   sgnal>>sval[i][0]>>sval[i][1]>>sval[i][2]>>sval[i][3]>>sval[i][4]>>sval[i][5]>>sval[i][6]>>sval[i][7]>>sval[i][8]>>sval[i][9]>>sval[i][10]>>sval[i][11]>>sval[i][12]>>sval[i][13]>>sval[i][14]>>sval[i][15];

 mcw>>wval[i][0]>>wval[i][1]>>wval[i][2]>>wval[i][3]>>wval[i][4]>>wval[i][5]>>wval[i][6]>>wval[i][7]>>wval[i][8]>>wval[i][9]>>wval[i][10]>>wval[i][11]>>wval[i][12]>>wval[i][13]>>wval[i][14]>>wval[i][15];

 mctop>>tval[i][0]>>tval[i][1]>>tval[i][2]>>tval[i][3]>>tval[i][4]>>tval[i][5]>>tval[i][6]>>tval[i][7]>>tval[i][8]>>tval[i][9]>>tval[i][10]>>tval[i][11]>>tval[i][12]>>tval[i][13]>>tval[i][14]>>tval[i][15];


 lumisignal=sval[i][6]/xs_signal;
 lumiw=wval[i][6]/xs_wjets;
 lumitop=tval[i][6]/xs_top;
 scale_signal= lumi/lumisignal;
 scale_w= lumi/lumiw;
 scale_top= lumi/lumitop;
 for (int j=6;j<16;j++){
   s_sb[i][j]=0.0;
   if (sval[i][j]>0) {
     s_sb[i][j]=fabs(sval[i][j]*scale_signal/sqrt(sval[i][j]*scale_signal+wval[i][j]*scale_w+tval[i][j]*scale_top));
   }
 }
 for (int j=0;j<6;j++){s_sb[i][j]=sval[i][j];}  
 }
 sgnal.close();
 mcw.close();
 mctop.close();
 // sort the significance array from higher to lower significance
 double temp;
 double itemp;
 for (int i=0;i<ndt;i++){
   for (int j=i+1;j<ndt;j++){
     if (s_sb[j][15]>s_sb[i][15]){
       for (int k=0;k<16;k++){
	 temp=s_sb[i][k];
	 s_sb[i][k]=s_sb[j][k];
	 s_sb[j][k]=temp;
	 itemp=sval[i][k];
	 sval[i][k]=sval[j][k];
	 sval[j][k]=itemp;
	 itemp=wval[i][k];
	 wval[i][k]=wval[j][k];
	 wval[j][k]=itemp;
	 itemp=tval[i][k];
	 tval[i][k]=tval[j][k];
	 tval[j][k]=itemp;
       }
     }
   }
 }

for (int i=0;i<ndt;i++){
  if ((wval[i][15]+tval[i][15])<1) continue;
  ssb<<"mupt"<<muonptcut[int(s_sb[i][0])]<<" "<<"dphijetmet"<<dphijetmetcut[int(s_sb[i][1])]<<" "<<"ljetpt"<<lptcut[int(s_sb[i][2])]<<" "<<"met"<<metcut[int(s_sb[i][3])]<<" "<<"mt"<<mtcut[int(s_sb[i][4])]<<" "<<"dphi-pi"<<dphicut[int(s_sb[i][5])]<<" ";
  for (int j=6;j<15;j++){
    ssb<<s_sb[i][j]<<" ";
//    if (i>5) ssb<<fixed<<setprecision(4)<<s_sb[i][j]<<" ";
  }
  ssb<<"s/sqrt(s+b)="<<s_sb[i][15]<<" ";
  ssb<<"nsignal="<<sval[i][15]<<"; nwjtes="<<wval[i][15]<<" ; ntop="<<tval[i][15]<<endl;
  //  ssb<<endl;
 } 
 ssb.close();
}
