make compile_ROOT_Delphes
typeset -i start=$1
typeset -i end=$2

mkdir signal/results/$3$4
for ((j=$start;j<=$end;j++))
        do
	      ln -sf signal/results/$3$4/signal$j.txt OUTFILE.TXT
       ./scan /DiscoB/temp/temp_fpahlen/signal_$3$4/tag_$3_$4_delphes_events$j.root  
        done

