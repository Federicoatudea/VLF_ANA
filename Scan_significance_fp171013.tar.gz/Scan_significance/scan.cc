#include <iostream>
#include <stdlib.h> 
#include "ROOTFunctions.h"
#include "DelphesFunctions.h"
#include "scan.h"

//modifiy original scan, see scan.cc.back

using namespace std;

// Global variables
double pi = 4.0*atan(1.0);

// begining of the program
int main(int argc, char *argv[]) {
  
  // Open Tchain inside Delphes
  TChain chain("Delphes");
  chain.Add(argv[1]);    
  
  // Create object of class ExRootTreeReader
  ExRootTreeReader *treeReader = new ExRootTreeReader(&chain);
  
  // Number of entries access
  long int numberOfEntries = treeReader->GetEntries();
  
  // Get pointers to branches used in this analysis 
  TClonesArray *branchJet = treeReader->UseBranch("Jet");
  TClonesArray *branchMuon = treeReader->UseBranch("Muon");
  TClonesArray *branchMissingET = treeReader->UseBranch("MissingET");


  // Loop over all events
  
   int cutflow[10]={10*0};
   int scan6[10][8][6][5][10][6]={144000*0};
   int scan5[10][8][6][5][10]={24000*0};
   int scan4[10][8][6][5]={2400*0};
   int scan3[10][8][6]={480*0};
   int scan2[10][8]={80*0};
   int scan1[10]={10*0};

   double muonptcut[10]={4.0,6.0,6.0,8.0,10.0,12.0,15.0,20.0,24.0,28.0};
   int njetscut[4]={1,2,3,4}; //dont use this cut
   double lptcut[6]={50.0,100.0,150.0,200.0,250.0,300.0};
   double metcut[5]={50.0,100.0,150.0,200.0,300.0};
   double mtcut[10]={0.0,2.0,4.0,8.0,12.0,16.0,20.0,30.0,40.0,60.0};
   double dphicut[6]={0.0,0.5,1.0,1.5,2.0,3.0};
   double dphijetmetcut[8]={0.1,0.2,0.4,0.6,1.0,1.5,2.0,3.0};  // cuts high |jet-met|-pi, selects backtoback jetmet

   int nshow=1000;
   
   //  std::cout<<" Total events = "<<numberOfEntries<<endl;
  for ( Int_t entry = 0; entry < numberOfEntries; ++entry ){
    
    // Load selected branches with data from specified event
    if (entry%nshow == 0 || entry ==numberOfEntries-1)
       {
	 std::cout<<" # events processed ="<<entry<<std::endl;
       } 
    
    cutflow[0]++;
    treeReader->ReadEntry(entry);
    int Numjets = branchJet->GetEntries();     
    int NumMuons = branchMuon->GetEntries();
   //Creating pointer for each particle
    MissingET *metpointer;
    Muon *muonpointer;
    Jet *jeti;
    metpointer = (MissingET*)branchMissingET->At(0);
    muonpointer = (Muon*)branchMuon->At(0);
    int nbtags=0;

    int njets30=0;
    double htx=0.0;
    double hty=0.0;
    double htz=0.0;
    double mht=0.0;
    double ht=0.0;
    double mt_mumet,mt_jetmet,mt_mujet,rmumet,rjetmet,rmujet;
    double dphi_mujet, dphi_mumet,dphi_jetmet;
    double leadingpt;

 

   
    for(Int_t i = 0; i < Numjets; i++){
      jeti = (Jet*) branchJet->At(i);      
      if (jeti->PT>30&&jeti->Eta*jeti->Eta<25.0) {
	njets30++;
	double theta=2.0*atan(exp(-jeti->Eta));
	double phii=pi+jeti->Phi;
	htx+=jeti->PT*sin(theta)*cos(phii);
	hty+=jeti->PT*sin(theta)*sin(phii);
	htz+=jeti->PT*cos(theta);
      }
     }
    
//emulate monojet trigger: MET>110 GeV and MHT>110 GeV
    mht=sqrt(htx*htx+hty*hty+htz*htz);
    //    cout<<" MET = "<<metpointer->MET<<" ;  MHT = "<<mht<<endl;
    
    if ((metpointer->MET<110)||(mht<110)) continue;
    // if ((metpointer->MET<100)) continue;
    cutflow[1]++;  // # events after trigger condition

    //cout<<"after trigger"<<endl;
   
      

    //cout<<"starting the scan"<<endl;
 //verify that there are muons
        
    if(NumMuons==1){
      cutflow[2]++;     
      dphi_mumet=fmod((2*pi+muonpointer->Phi-metpointer->Phi),2*pi);
      mt_mumet=sqrt(2*muonpointer->PT*metpointer->MET*(1-cos(dphi_mumet)));
      if (metpointer->MET>0) rmumet=muonpointer->PT/metpointer->MET;
      for(Int_t i = 0; i < 1; i++){
	jeti = (Jet*) branchJet->At(i);
	if (i==0) {  // leading jet condition
	  leadingpt=jeti->PT;
	  //cout<<"ljet_pt="<<leadingpt<<endl;
	  //cout<<"mu_ pt="<<muonpointer->PT<<endl;
	  dphi_mujet=fmod((2*pi+muonpointer->Phi-jeti->Phi),2*pi);
	  dphi_jetmet=fmod((2*pi+jeti->Phi-metpointer->Phi),2*pi);
	  
	  mt_mujet=sqrt(2*muonpointer->PT*jeti->PT*(1-cos(dphi_mujet)));
	  mt_jetmet=sqrt(2*jeti->PT*metpointer->MET*(1-cos(dphi_jetmet)));
	  if (metpointer->MET>0) rjetmet=jeti->PT/metpointer->MET;
	  if (jeti->PT>0) rmujet=muonpointer->PT/jeti->PT;
	  
	}
	
      }
      
      if (Numjets>0){
	cutflow[3]++;
	for (int i1=0;i1<10;i1++){ //loop over pt cuts
	  if (muonpointer->PT<muonptcut[i1]) {
	    scan1[i1]++;
	    //for (int i2=0;i2<4;i2++){ //loop over njets cuts
	    //  if (Numjets<=njetscut[i2]) {
	    for (int i2=0;i2<8;i2++){ //loop over dphijetmet cuts
	      if (fabs(dphi_jetmet-pi)<=dphijetmetcut[i2]) {
		scan2[i1][i2]++;
		for (int i3=0;i3<6;i3++){ //loop leading jet pt cuts
		  if (leadingpt>=lptcut[i3]) {
		    scan3[i1][i2][i3]++;
		    for (int i4=0;i4<5;i4++){ //loop over met cuts
		      if (metpointer->MET>=metcut[i4]) {
			scan4[i1][i2][i3][i4]++;
			for (int i5=0;i5<10;i5++){ //loop over mt cuts
			  if (mt_mumet>=mtcut[i5]) {
			    scan5[i1][i2][i3][i4][i5]++;
			    for (int i6=0;i6<6;i6++){ //loop over dphi cuts
			      if (fabs(dphi_mumet-pi)>=dphicut[i6]) {
				scan6[i1][i2][i3][i4][i5][i6]++;
			      } //if of dphi cut6
			    } //loop over dphi cut
			  } //if of mt cut5
			} //loop over mt cut		       
		      } //if of met cut4
		    } //loop over met cut		   
		  } //if of leading jet pt cut3
		} //loop over leading jet pt cut	       
	      } //if of njets cut2
	    } //loop over njets cut
	  } //if of muon pt cut1
	} //loop over pt cuts
      }//if numjets>0
    }//IF NMUONS==1
    
  } //end loop over entries
  
  ofstream outfile("OUTFILE.TXT");
  
  for (int i1=0;i1<10;i1++){ //loop over pt cuts
    scan1[i1];
    for (int i2=0;i2<8;i2++){ //loop over njets cuts
      scan2[i1][i2];
      for (int i3=0;i3<6;i3++){ //loop leading jet pt cuts
	scan3[i1][i2][i3];
	for (int i4=0;i4<5;i4++){ //loop over met cuts
	  scan4[i1][i2][i3][i4];
	  for (int i5=0;i5<10;i5++){ //loop over mt cuts
	    scan5[i1][i2][i3][i4][i5];
	    for (int i6=0;i6<6;i6++){ 
	      outfile<<i1<<" "<<i2<<" "<<i3<<" "<<i4<<" "<<i5<<" "<<i6<<" "<<cutflow[0]<<"  "<<cutflow[1]<<" ";
	      outfile<<cutflow[2]<<" "<<cutflow[3]<<" "<<scan1[i1]<<" "<<scan2[i1][i2]<<" "<<scan3[i1][i2][i3]<<" ";
	      outfile<<scan4[i1][i2][i3][i4]<<" "<<scan5[i1][i2][i3][i4][i5]<<" "<<scan6[i1][i2][i3][i4][i5][i6]<<endl;
	    }
	  }
	}
      }
    }
  }
  
  outfile.close();
  cout<<"######################### CUT FLOW SUMMARY ###############"<<endl;
cout<<"                         TOTAL NUMBER OF EVENTS  [0] = "<<cutflow[0]<<endl;
cout<<" ------------------------------------------------------------"<<endl;
 cout<<" MET>110, MHT>110                     [1] = "<<cutflow[1]<< "   ; relative eff. ="<<float(cutflow[1])/float(cutflow[0])<<endl;
 cout<<" Exactly 1 muon                     [2] = "<<cutflow[2]<< "   ; relative eff. ="<<float(cutflow[2])/float(cutflow[1])<<endl;
cout<<" nJETS>0                            [3] = "<<cutflow[3]<< "   ; relative eff. ="<<float(cutflow[3])/float(cutflow[2])<<endl;
cout<<"####################################################################"<<endl;


} //end program


    


 


 





   

